﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Perguntas.DAL;
using WebCheckList.Models;

namespace WebCheckList.Controllers
{
    public class QuestaoController : Controller
    {
        public IActionResult Index()
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
            IQueryable<Questao> questao = rep.GetAll();

            
            return View(questao);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Questao questao)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());

            rep.Add(questao);

            //return RedirectToAction("Index","Questao");
            return RedirectToRoute(new { controller = "Questao", action = "Index"});

        }

        public IActionResult Edit(int id)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
            return View(rep.Get(id));
        }

        [HttpPost]
        public IActionResult Edit(Questao questao)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());

            rep.Update(questao);
            //return RedirectToAction("Index","Questao");
            return RedirectToRoute(new { controller = "Questao", action = "Index" });
        }

        public IActionResult Details(int id)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
            return View(rep.Get(id));
        }

        public IActionResult Delete(int id)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
            return View(rep.Get(id));
        }

        [HttpPost]
        public IActionResult Delete(Questao questao)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());

            rep.Remove(rep.Get(questao.Id));
            //return RedirectToAction("Index","Questao");
            return RedirectToRoute(new { controller = "Questao", action = "Index" });
        }


    }
}