﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebCheckList.Models
{
    [Table("vw_usuario_checklist")]
    public class Usuario
    {
        [Key]
        [Column("id_usuario")]
        public int Id { get; set; }

        [Column("usuario")]
        [Required(ErrorMessage = "Informe o login do usuários")]
        public String Login { get; set; }

        [Column("senha")]
        [Required(ErrorMessage = "Informe a senha do usuário")]
        public String Senha { get; set; }


        [Column("nome")]
        public String Nome { get; set; }
    }
}
