﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebCheckList.Models
{
    [Table("C_Viagem")]
    public class Viagem
    {
      
        public Viagem()
        {
            CheckList = new HashSet<CheckList>();
           
        }

        [Key]
        [Column("viagem")]
        public int Id { get; set; }

        [Column("saida_km")]
        public int? KmSaida { get; set; }

        [Column("eh_semireboque")]
        public Boolean? SemiReboque { get; set; }

        [Column("saida_semireboque_km")]
        public int? KmSemiReboqueSaida { get; set; }

        [Column("eh_bitrem")]
        public Boolean? BiTrem { get; set; }

        [Column("saida_bitrem_km")]
        public int? KmBiTremSaida { get; set; }

        [Column("id_motorista")]
        public int? MotoristaId { get; set; }

        [Column("id_cliente_saida")]
        public int? ClienteSaidaId { get; set; }

        [Column("id_cliente_retorno")]
        public int? ClienteDestinoId { get; set; }

        [Column("chegada_km")]
        public int? KmRetorno { get; set; }

        [Column("retorno_bitrem_km")]
        public int? KmBiTremRetorno { get; set; }

        [Column("retorno_semireboque_km")]
        public int? KmSemiReboqueRetorno { get; set; }

        [Column("saida")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? DataSaida { get; set; }

        [Column("chegada")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? DataRetorno { get; set; }
        
        public virtual ICollection<CheckList> CheckList { get; set; }
        
    }
}
