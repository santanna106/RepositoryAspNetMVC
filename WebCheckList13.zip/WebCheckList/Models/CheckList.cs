﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebCheckList.Models
{
    [Table("checklist_viagem")]
    public class CheckList
    {
        public string[] Respostas = new[] { "S", "N", "NA" };
        [Key]
        [Column("id_checklist")]
        public int Id { get; set; }

        [Column("id_viagem")]
        public int ViagemId { get; set; }
        public virtual Viagem Viagem { get; set; }
        [Column("id_questao")]
        public int QuestaoId { get; set; }
        public virtual Questao Questao { get; set; }

        [Column("resposta_saida")]
        public string RespostaSaida { get; set; }
        [Column("resposta_retorno")]
        public string RespostaRetorno { get; set; }
        [Column("quantidade")]
        public int Quantidade { get; set; }
        [Column("obrigatorio")]
        public Boolean Obrigatorio { get; set; }

        [Column("nome_questao")]
        public String NomeQuestao { get; set; }

        [Column("id_motorista")]
        public int MotoristaId { get; set; }



    }
}
