﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebCheckList.Models
{
    [Table("questao_cheklist")]
    public class Questao
    {
        public Questao()
        {
            CheckList = new HashSet<CheckList>();
        }
        [Key]
        [Column("id_questao")]
        public int Id { get; set; }
        [Column("sentenca")]
        public string Sentenca { get; set; }

        [Column("obrigatorio")]
        public Boolean Obrigatorio { get; set; }

        [Column("quantitativo")]
        public Boolean Quantitativo { get; set; }

        public virtual ICollection<CheckList> CheckList { get; set; }
    }
}
