﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WebCheckList.Models
{
    public class Usuario
    {
        
        public int Id { get; set; }
        [Required(ErrorMessage = "Informe o login do usuários")]
        public String Login { get; set; }
        [Required(ErrorMessage = "Informe a senha do usuário")]
        public String Senha { get; set; }

        public String Nome { get; set; }
    }
}
