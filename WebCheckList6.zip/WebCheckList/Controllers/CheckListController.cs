﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Perguntas.DAL;
using WebCheckList.Models;
using X.PagedList;

namespace WebCheckList.Controllers
{
    public class CheckListController : Controller
    {
  
        public IActionResult Index(string codViagem = "" , int? pagina=1)
        {

            

            Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());



            var numPagina = pagina ?? 1;
            ViewBag.Busca = codViagem;

            int cod = 0; 
            try
            {
                cod = Convert.ToInt32(codViagem);
            }
            catch (Exception)
            {
                cod = 0;
            }
            


            if (cod != 0)
            {
                var viagens = rep.GetAll().Where(v => v.Id == cod).ToPagedList(numPagina, 2);
                ViewBag.viagens = viagens;
            }
            else
            {
                var viagens = rep.GetAll().OrderBy(v => v.Id).ToPagedList(numPagina, 2);
                ViewBag.viagens = viagens;
            }


            


            return View();
        }
        [HttpPost]
        public IActionResult FormCheckList(String Teste)
        {
            String x = Teste;
            return RedirectToAction("Index");
        }

            public IActionResult FormCheckList(int id)
        {
           
            Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());

            var checks = from c in repCheck.GetAll()
                           select c;

            checks = checks.Where(c => c.ViagemId == id);

            if(checks.Count() == 0)
            {
                insereQuestoesViagem(id);
                checks = from c in repCheck.GetAll()
                         select c;

                checks = checks.Where(c => c.ViagemId == id);
            }

            
            ViewBag.checks = checks;

            return View();

        }




        public void insereQuestoesViagem(int viagemId)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
            var questoes = rep.GetAll();
            CheckList checkAux = null;
            Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());
            foreach (Questao questao in questoes)
            {
                checkAux = new CheckList();
                checkAux.ViagemId = viagemId;
                checkAux.QuestaoId = questao.Id;
                checkAux.Obrigatorio = questao.Obrigatorio;
                

               repCheck.Add(checkAux);


            }

        }



    }
    }