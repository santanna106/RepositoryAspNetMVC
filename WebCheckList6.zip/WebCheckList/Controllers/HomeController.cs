﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebCheckList.Models;
using Microsoft.AspNetCore.Http;
using Perguntas.DAL;

namespace WebCheckList.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Menu()
        {
            return View();
        }

        public IActionResult Login(int? id)
        {
            if (id != null)
            {
                if (id == 0)
                {
                    HttpContext.Session.SetString("Senha", "");
                    HttpContext.Session.SetString("Nome", "");
                }
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Usuario u)
        {
            // HttpContext.Session.Clear

            Repository<Usuario> rep = new Repository<Usuario>(new BaseContext<Usuario>());

            var usuario = rep.GetAll().Where(v => v.Login.Equals(u.Login) && v.Senha.Equals(u.Senha) );
            if(usuario.Count() == 1)
            {
                Usuario usr = usuario.ToArray<Usuario>()[0];
                HttpContext.Session.SetString("Senha", usr.Senha);
                HttpContext.Session.SetString("Nome", usr.Nome);

                return RedirectToAction("Menu");
            }
            else
            {
                TempData["ErrorLogin"] = "Login ou Senha são inválidos!";
               
            }

            

            

            
             
           

            // esta action trata o post (login)
            //if (ModelState.IsValid) //verifica se é válido
            //{



            /*using (CadastroEntities dc = new CadastroEntities())
            {
                var v = dc.Usuarios.Where(a => a.NomeUsuario.Equals(u.NomeUsuario) && a.Senha.Equals(u.Senha)).FirstOrDefault();
                if (v != null)
                {*/
            //  Session["usuarioLogadoID"] = v.Id.ToString();
            // Session["nomeUsuarioLogado"] = v.NomeUsuario.ToString();
            // return RedirectToAction("Index");
            /*  }
          }*/
            //}
            return View(u);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
