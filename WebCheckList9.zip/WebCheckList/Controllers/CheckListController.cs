﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Perguntas.DAL;
using WebCheckList.Models;
using X.PagedList;

namespace WebCheckList.Controllers
{
    public class CheckListController : Controller
    {

        public IActionResult Index(string codViagem = "", int? pagina = 1)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());
                var numPagina = pagina ?? 1;
                ViewBag.Busca = codViagem;

                int cod = 0;
                try
                {
                    cod = Convert.ToInt32(codViagem);
                }
                catch (Exception)
                {
                    cod = 0;
                }



                if (cod != 0)
                {
                    var viagens = rep.GetAll().Where(v => v.Id == cod).ToPagedList(numPagina, 10);
                    ViewBag.viagens = viagens;
                }
                else
                {
                    var viagens = rep.GetAll().OrderBy(v => v.Id).ToPagedList(numPagina, 10);
                    ViewBag.viagens = viagens;
                }


            }


            return View();
        }

        public IActionResult AbreViagem(int id)
        {
            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                return View();
            }
            
        }

        [HttpPost]
        public IActionResult FormCheckList(IFormCollection collection)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
                var questoes = rep.GetAll();
                int viagemId = Convert.ToInt32(collection["ViagemId"]);

                Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());

                foreach (var questao in questoes)
                {
                    Boolean atualiza = false;
                    CheckList checkList = repCheck.GetAll().Where(v => v.ViagemId == viagemId && v.QuestaoId == questao.Id).First<CheckList>();
                    String saida = collection["S" + questao.Id];


                    if (saida != null)
                    {
                        checkList.RespostaSaida = saida;
                        atualiza = true;
                    }

                    String retorno = collection["R" + questao.Id];
                    if (retorno != null)
                    {
                        checkList.RespostaRetorno = retorno;
                        atualiza = true;
                    }

                    if (atualiza)
                    {
                        repCheck.Update(checkList);
                    }

                }
                return RedirectToAction("Index");
            }
        }

        public IActionResult FormCheckList(int id)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());

                var checks = from c in repCheck.GetAll()
                             select c;

                checks = checks.Where(c => c.ViagemId == id);

                if (checks.Count() == 0)
                {
                    insereQuestoesViagem(id);
                    checks = from c in repCheck.GetAll()
                             select c;

                    checks = checks.Where(c => c.ViagemId == id);
                }


                ViewBag.checks = checks;
                ViewBag.viagemId = id;

                return View();
            }

        }

        public void insereQuestoesViagem(int viagemId)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
            var questoes = rep.GetAll();
            CheckList checkAux = null;
            Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());
            foreach (Questao questao in questoes)
            {
                checkAux = new CheckList();
                checkAux.ViagemId = viagemId;
                checkAux.QuestaoId = questao.Id;
                checkAux.Obrigatorio = questao.Obrigatorio;
                checkAux.NomeQuestao = "Q" + questao.Id;
                checkAux.MotoristaId = Convert.ToInt32(HttpContext.Session.GetString("Id"));

                repCheck.Add(checkAux);


            }

        }

    }
}