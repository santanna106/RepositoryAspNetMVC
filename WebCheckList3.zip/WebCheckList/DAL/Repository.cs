﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Perguntas.DAL
{
    public class Repository<T> : IDisposable, IRepository<T> where T : class
    {
        protected readonly DbContext contexto;


        public Repository(DbContext contexto)

        {

            this.contexto = contexto;

        }


        public virtual void Add(T item)

        {

            contexto.Set<T>().Add(item);

            contexto.SaveChanges();

        }


        public virtual void Remove(T item)

        {

            contexto.Set<T>().Remove(item);

            contexto.SaveChanges();

        }


        public virtual void Update(T item)

        {

            contexto.Entry(item).State = EntityState.Modified;

            contexto.SaveChanges();

        }


        public virtual T Get(int id)

        {

            return contexto.Set<T>().Find(id);

        }


        public virtual IQueryable<T> GetAll()

        {

            return contexto.Set<T>();

        }


        public void Dispose()

        {

            contexto.Dispose();

        }



        
    }
}