﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace Perguntas.DAL
{
    public class BaseContext<T> : DbContext where T : class
    {
        public DbSet<T> DbSet
        {
            get;
            set;
        }
        public BaseContext() : base("Data Source=localhost;Initial Catalog=DBFrota_jrubem;Integrated Security=True;MultipleActiveResultSets=true")
        {
            //Caso a base de dados não tenha sido criada, 
            //ao iniciar a aplicação iremos criar
            Database.SetInitializer<BaseContext<T>>(null);
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //Neste momento não iremos fazer nada, 
            //iremos voltar mais para frente para criar nosso mapeamos dinamicos
            //Retira a Pluralizacao
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            base.OnModelCreating(modelBuilder);
        }
        public virtual void ChangeObjectState(object model, EntityState state)
        {
            //Aqui trocamos o estado do objeto, 
            //facilita quando temos alterações e exclusões
            ((IObjectContextAdapter)this)
                          .ObjectContext
                          .ObjectStateManager
                          .ChangeObjectState(model, state);
        }
    }
}