﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebCheckList.Models
{
    [Table("rh")]
    public class Usuario
    {
        [Key]
        [Column("id_rh")]
        public int Id { get; set; }
        [Required(ErrorMessage = "Informe o login do usuários")]
        [Column("usuario")]
        public String Login { get; set; }
        [Required(ErrorMessage = "Informe a senha do usuário")]
        public String Senha { get; set; }

        public String Nome { get; set; }
    }
}
