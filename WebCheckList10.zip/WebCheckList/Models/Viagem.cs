﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebCheckList.Models
{
    public class Viagem
    {
        public Viagem()
        {
            CheckList = new HashSet<CheckList>();
            KmSaida = 0;
        }
        public int Id { get; set; }

        public int? KmSaida { get; set; }
        public Boolean? SemiReboque { get; set; }

        public int? KmSemiReboqueSaida { get; set; }

        public Boolean? BiTrem { get; set; }
        public int? KmBiTremSaida { get; set; }

        public int? MotoristaId { get; set; }

        public int? ClienteSaidaId { get; set; }

        public int? ClienteDestinoId { get; set; }

        public int? KmRetorno { get; set; }

        public int? KmBiTremRetorno { get; set; }

        public int? KmSemiReboqueRetorno { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? DataSaida { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? DataRetorno { get; set; }

        public virtual ICollection<CheckList> CheckList { get; set; }

    }
}
