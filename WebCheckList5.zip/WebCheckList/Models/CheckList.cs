﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebCheckList.Models
{
    public class CheckList
    {
        public int Id { get; set; }

        public int ViagemId { get; set; }
        public virtual Viagem Viagem { get; set; }
        public int QuestaoId { get; set; }
        public virtual Questao Questao { get; set; }
    
        public string RespostaSaida { get; set; }
        public string RespostaRetorno { get; set; }

        public int Quantidade { get; set; }
        public Boolean Obrigatorio { get; set; }



    }
}
