﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebCheckList.Models
{
    public class Questao
    {
        public Questao()
        {
            CheckList = new HashSet<CheckList>();
        }
        public int Id { get; set; }
        public string Sentenca { get; set; }

        public Boolean Obrigatorio { get; set; }

        public Boolean Quantitativo { get; set; }

        public virtual ICollection<CheckList> CheckList { get; set; }
    }
}
