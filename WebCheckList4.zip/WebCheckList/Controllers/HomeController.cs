﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebCheckList.Models;
using Microsoft.AspNetCore.Http;
using Perguntas.DAL;

namespace WebCheckList.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Usuario u)
        {
            // HttpContext.Session.Clear

            Repository<Usuario> rep = new Repository<Usuario>(new BaseContext<Usuario>());

            var usuario = rep.GetAll().Where(v => v.Login.Equals(u.Login) && v.Senha.Equals(u.Senha) );
            if(usuario.Count() == 1)
            {
                HttpContext.Session.SetString(u.Login, u.Senha);
                String nome = HttpContext.Session.GetString(u.Login);
            }else
            {
                return RedirectToAction("Login");
            }

            

            

            return RedirectToAction("Index");
             
           

            // esta action trata o post (login)
            //if (ModelState.IsValid) //verifica se é válido
            //{



            /*using (CadastroEntities dc = new CadastroEntities())
            {
                var v = dc.Usuarios.Where(a => a.NomeUsuario.Equals(u.NomeUsuario) && a.Senha.Equals(u.Senha)).FirstOrDefault();
                if (v != null)
                {*/
            //  Session["usuarioLogadoID"] = v.Id.ToString();
            // Session["nomeUsuarioLogado"] = v.NomeUsuario.ToString();
            // return RedirectToAction("Index");
            /*  }
          }*/
            //}
            return View(u);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
