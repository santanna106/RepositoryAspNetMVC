﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebCheckList.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public String Login { get; set; }
        public String Senha { get; set; }
    }
}
