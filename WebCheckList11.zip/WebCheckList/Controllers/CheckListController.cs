﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Perguntas.DAL;
using WebCheckList.Models;
using X.PagedList;

namespace WebCheckList.Controllers
{
    public class CheckListController : Controller
    {

        public IActionResult Index(string codViagem = "", int? pagina = 1)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());
                var numPagina = pagina ?? 1;
                ViewBag.Busca = codViagem;

                int cod = 0;
                try
                {
                    cod = Convert.ToInt32(codViagem);
                }
                catch (Exception)
                {
                    cod = 0;
                }



                if (cod != 0)
                {
                    var viagens = rep.GetAll().Where(v => v.Id == cod).ToPagedList(numPagina, 10);
                    ViewBag.viagens = viagens;
                }
                else
                {
                    var viagens = rep.GetAll().OrderBy(v => v.Id).ToPagedList(numPagina, 10);
                    ViewBag.viagens = viagens;
                }


            }


            return View();
        }


        public IActionResult IndexRetorno(string codViagem = "", int? pagina = 1)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());
                var numPagina = pagina ?? 1;
                ViewBag.Busca = codViagem;

                int cod = 0;
                try
                {
                    cod = Convert.ToInt32(codViagem);
                }
                catch (Exception)
                {
                    cod = 0;
                }



                if (cod != 0)
                {
                    var viagens = rep.GetAll().Where(v => v.Id == cod).ToPagedList(numPagina, 10);
                    ViewBag.viagens = viagens;
                }
                else
                {
                    var viagens = rep.GetAll().OrderBy(v => v.Id).ToPagedList(numPagina, 10);
                    ViewBag.viagens = viagens;
                }


            }


            return View();
        }


        public IActionResult AbreViagemRetorno(int id)
        {
            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());
                Viagem viagem = rep.Get(id);
                ViewBag.viagemId = id;
                ViewBag.motoristaId = HttpContext.Session.GetString("Id");
                ViewBag.motoristaNome = HttpContext.Session.GetString("Nome");
                if (viagem.DataRetorno == null)
                {
                    ViewBag.dataRetorno = DateTime.Now;
                }
                else
                {
                    ViewBag.dataRetorno = viagem.DataRetorno;
                }

                if (viagem.KmBiTremRetorno != null)
                {
                    ViewBag.KmBiTremRetorno = viagem.KmBiTremRetorno;
                }

                if (viagem.KmRetorno != null)
                {
                    ViewBag.KmRetorno = viagem.KmRetorno;
                }

                if (viagem.KmSemiReboqueRetorno != null)
                {
                    ViewBag.KmSemiReboqueRetorno = viagem.KmSemiReboqueRetorno;
                }

                if (viagem.SemiReboque != null)
                {
                    ViewBag.SemiReboque = viagem.SemiReboque;
                }

                if (viagem.BiTrem != null)
                {
                    ViewBag.BiTrem = viagem.BiTrem;
                }

                return View(viagem);
            }

        }

        [HttpPost]
        public IActionResult AbreViagemRetorno(IFormCollection collection)
        {
            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());
                Viagem viagem = rep.Get(Convert.ToInt32(collection["viagem"]));
                viagem.DataRetorno = DateTime.Parse(collection["data_retorno"]);
                viagem.KmRetorno = Convert.ToInt32(collection["km_retorno"]);
                Boolean semiReboque = false;
                if (collection["check_semireboque"].Equals("on"))
                {
                    semiReboque = true;
                }

                viagem.SemiReboque = semiReboque;
                try
                {
                    viagem.KmSemiReboqueRetorno = Convert.ToInt32(collection["km_semireboque"]);
                }
                catch
                {
                    viagem.KmSemiReboqueRetorno = null;
                }

                Boolean biTrem = false;
                if (collection["check_bitrem"].Equals("on"))
                {
                    biTrem = true;
                }
                viagem.BiTrem = biTrem;

                try
                {
                    viagem.KmBiTremRetorno = Convert.ToInt32(collection["km_bitrem"]);
                }
                catch
                {
                    viagem.KmBiTremRetorno = null;
                }

                viagem.MotoristaId = Convert.ToInt32(HttpContext.Session.GetString("Id"));

                rep.Update(viagem);
                return RedirectToAction("IndexRetorno");
            }

        }



        public IActionResult AbreViagem(int id)
        {
            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());
                Viagem viagem = rep.Get(id);
                ViewBag.viagemId = id;
                ViewBag.motoristaId = HttpContext.Session.GetString("Id");
                ViewBag.motoristaNome = HttpContext.Session.GetString("Nome");
                if(viagem.DataSaida == null)
                {
                    ViewBag.dataSaida = DateTime.Now;
                }
                else
                {
                    ViewBag.dataSaida = viagem.DataSaida;
                }

                if (viagem.KmBiTremSaida != null)
                {
                    ViewBag.KmBiTremSaida = viagem.KmBiTremSaida;
                }

                if (viagem.KmSaida != null)
                {
                    ViewBag.KmSaida = viagem.KmSaida;
                }

                if (viagem.KmSemiReboqueSaida != null)
                {
                    ViewBag.KmSemiReboqueSaida = viagem.KmSemiReboqueSaida;
                }

                if (viagem.SemiReboque != null)
                {
                    ViewBag.SemiReboque = viagem.SemiReboque;
                }

                if (viagem.BiTrem != null)
                {
                    ViewBag.BiTrem = viagem.BiTrem;
                }

                return View(viagem);
            }
            
        }

        [HttpPost]
        public IActionResult AbreViagem(IFormCollection collection)
        {
            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                Repository<Viagem> rep = new Repository<Viagem>(new BaseContext<Viagem>());
                Viagem viagem = rep.Get(Convert.ToInt32(collection["viagem"]));
                viagem.DataSaida = DateTime.Parse(collection["data_saida"]);
                viagem.KmSaida = Convert.ToInt32(collection["km_saida"]);
                Boolean semiReboque = false;
                if (collection["check_semireboque"].Equals("on"))
                {
                    semiReboque = true;
                }

                viagem.SemiReboque = semiReboque;
                try
                {
                    viagem.KmSemiReboqueSaida = Convert.ToInt32(collection["km_semireboque"]);
                }
                catch
                {
                    viagem.KmSemiReboqueSaida = null;
                }
               
                Boolean biTrem = false;
                if (collection["check_bitrem"].Equals("on"))
                {
                    biTrem = true;
                }
                viagem.BiTrem = biTrem;

                try
                {
                    viagem.KmBiTremSaida = Convert.ToInt32(collection["km_bitrem"]);
                }
                catch
                {
                    viagem.KmBiTremSaida = null;
                }
                
                viagem.MotoristaId = Convert.ToInt32(HttpContext.Session.GetString("Id"));

                rep.Update(viagem);
                return RedirectToAction("Index");
            }

        }

        [HttpPost]
        public IActionResult FormCheckList(IFormCollection collection)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
                var questoes = rep.GetAll();
                int viagemId = Convert.ToInt32(collection["ViagemId"]);

                Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());

                foreach (var questao in questoes)
                {
                    Boolean atualiza = false;
                    CheckList checkList = repCheck.GetAll().Where(v => v.ViagemId == viagemId && v.QuestaoId == questao.Id).First<CheckList>();
                    String saida = collection["S" + questao.Id];


                    if (saida != null)
                    {
                        checkList.RespostaSaida = saida;
                        atualiza = true;
                    }

                    if (atualiza)
                    {
                        repCheck.Update(checkList);
                    }

                }
                return RedirectToAction("Index");
            }
        }

        public IActionResult FormCheckList(int id)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());

                var checks = from c in repCheck.GetAll()
                             select c;

                checks = checks.Where(c => c.ViagemId == id);

                if (checks.Count() == 0)
                {
                    insereQuestoesViagem(id);
                    checks = from c in repCheck.GetAll()
                             select c;

                    checks = checks.Where(c => c.ViagemId == id);
                }


                ViewBag.checks = checks;
                ViewBag.viagemId = id;

                return View();
            }

        }


        public IActionResult FormCheckListRetorno(int id)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());

                var checks = from c in repCheck.GetAll()
                             select c;

                checks = checks.Where(c => c.ViagemId == id);

                if (checks.Count() == 0)
                {
                    insereQuestoesViagem(id);
                    checks = from c in repCheck.GetAll()
                             select c;

                    checks = checks.Where(c => c.ViagemId == id);
                }


                ViewBag.checks = checks;
                ViewBag.viagemId = id;

                return View();
            }

        }

        [HttpPost]
        public IActionResult FormCheckListRetorno(IFormCollection collection)
        {

            if (HttpContext.Session.GetString("Nome") == "" || HttpContext.Session.GetString("Nome") == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
                var questoes = rep.GetAll();
                int viagemId = Convert.ToInt32(collection["ViagemId"]);

                Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());

                foreach (var questao in questoes)
                {
                    Boolean atualiza = false;
                    CheckList checkList = repCheck.GetAll().Where(v => v.ViagemId == viagemId && v.QuestaoId == questao.Id).First<CheckList>();
             

                    String retorno = collection["R" + questao.Id];
                    if (retorno != null)
                    {
                        checkList.RespostaRetorno = retorno;
                        atualiza = true;
                    }

                    if (atualiza)
                    {
                        repCheck.Update(checkList);
                    }

                }
                return RedirectToAction("IndexRetorno");
            }
        }

        public void insereQuestoesViagem(int viagemId)
        {
            Repository<Questao> rep = new Repository<Questao>(new BaseContext<Questao>());
            var questoes = rep.GetAll();
            CheckList checkAux = null;
            Repository<CheckList> repCheck = new Repository<CheckList>(new BaseContext<CheckList>());
            foreach (Questao questao in questoes)
            {
                checkAux = new CheckList();
                checkAux.ViagemId = viagemId;
                checkAux.QuestaoId = questao.Id;
                checkAux.Obrigatorio = questao.Obrigatorio;
                checkAux.NomeQuestao = "Q" + questao.Id;
                checkAux.MotoristaId = Convert.ToInt32(HttpContext.Session.GetString("Id"));

                repCheck.Add(checkAux);


            }

        }

    }
}